import React, { useState } from 'react';
import { TextField, Button, Typography } from '@mui/material';
import './login.css';

const LoginForm = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = () => {
    if (email && password) {
        // Store email and password in local storage
        localStorage.setItem('email', email);
        localStorage.setItem('password', password);
    
        // Redirect to dashboard or perform other actions
        window.location.href = '/dashboard';
      } else {
        setError('Please provide both email and password');
      }
  };

  return (
    <div class='login-page-container'>
      <TextField
        label="Email Address"
        variant="outlined"
        fullWidth
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        style={{ marginBottom: '10px' }}
      />
      <TextField
        type="password"
        label="Password"
        variant="outlined"
        fullWidth
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        style={{ marginBottom: '10px' }}
      />
      <Button variant="contained" color="primary" onClick={handleLogin}>
        Login
      </Button>
      {error && <Typography variant="body2" color="error">{error}</Typography>}
    </div>
  );
};

export default LoginForm;
