import React from 'react';
import LoginForm from './loginform';
import { Link } from 'react-router-dom';
import './login.css';



const LoginPage = () => {
  return (
    <div>
      <h1 class='login-page-title'>Login</h1>
      <LoginForm />
      <div class='register-link'>
      <Link to="/register">Don't have an account? Register</Link>
      </div>
    </div>
  );
};

export default LoginPage;
