// RegistrationPage.js
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { TextField, Button } from '@mui/material';
import './register.css'

const RegistrationPage = () => {
 
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Perform validation
    if (formData.firstName.trim() === '' || formData.lastName.trim() === '' || formData.email.trim() === '' || formData.password.trim() === '' || formData.confirmPassword.trim() === '') {
      setErrors({ message: 'All fields are required' });
      return;
    }
    if (!isValidEmail(formData.email)) {
      setErrors({ message: 'Invalid email address' });
      return;
    }
    if (formData.password !== formData.confirmPassword) {
      setErrors({ message: 'Passwords do not match' });
      return;
    }
    // Redirect to dashboard upon successful registration
    window.location.href = '/login';
  };

  const isValidEmail = (email) => {
    // Basic email validation
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  return (
    <div class='registration-page-container'>
      <h1 class='registration-page-title '>Registration</h1>
      <form onSubmit={handleSubmit}>
        <div class='form-input'>
        <TextField
          label="First Name"
          variant="outlined"
          fullWidth
          name="firstName"
          value={formData.firstName}
          onChange={handleChange}
        />
        <TextField
          label="Last Name"
          variant="outlined"
          fullWidth
          name="lastName"
          value={formData.lastName}
          onChange={handleChange}
        />
        <TextField
          label="Email Address"
          variant="outlined"
          fullWidth
          name="email"
          value={formData.email}
          onChange={handleChange}
        />
        <TextField
          type="password"
          label="Password"
          variant="outlined"
          fullWidth
          name="password"
          value={formData.password}
          onChange={handleChange}
        />
        <TextField
          type="password"
          label="Confirm Password"
          variant="outlined"
          fullWidth
          name="confirmPassword"
          value={formData.confirmPassword}
          onChange={handleChange}
        />
        </div>
        <div class='error-message'>
        {errors.message && <p style={{ color: 'red' }}>{errors.message}</p>}
        </div>
        <Button class='submit-button' variant="contained" color="primary" type="submit">
          Register
        </Button>
      </form>
      <Link class='login-link' to="/">Already have an account? Login</Link>
    </div>
  );
};

export default RegistrationPage;
