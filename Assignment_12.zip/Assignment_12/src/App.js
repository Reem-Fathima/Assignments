import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import LoginPage from './components/login/login';
import RegistrationPage from './components/register/register';
import DashboardPage from './dashboard/dashboard';



const App = () => {
  return (
    <Router>
      <Routes>
      <Route path="/" exact element={<LoginPage />} />
      <Route path="/register" element ={<RegistrationPage/>}/>
      <Route path="/dashboard" exact element={<DashboardPage/>} />
      </Routes>
      
    </Router>
  );
};

export default App;
