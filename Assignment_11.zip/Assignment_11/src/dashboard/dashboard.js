// Dashboard.js
import React, { useContext } from "react";
import { Link, useInRouterContext } from "react-router-dom";


function Dashboard() {
  const { username } = useContext(useInRouterContext);

  return (
    <div>
      <h1>Welcome to Dashboard, {username}!</h1>
      <Link to="/profile">Go to Profile</Link>
    </div>
  );
}

export default Dashboard;
