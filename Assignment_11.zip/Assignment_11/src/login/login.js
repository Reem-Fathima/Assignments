
import React, { useContext } from "react";

import UserContext from "../usercontext/UserContext";


function LoginPage() {
  const { setUsername } = useContext(UserContext);
//   const history = useHistory();

  const handleLogin = () => {
    const username = "user123"; // You can implement actual login logic here
    setUsername(username);
    window.location.href='/dashboard'
  };

  return (
    <div>
      <h1>Login Page</h1>
      <button onClick={handleLogin}>Login</button>
    </div>
  );
}

export default LoginPage;
