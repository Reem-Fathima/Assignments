// Profile.js
import React, { useEffect, useState } from "react";

function Profile() {
  const [userData, setUserData] = useState(null);

  useEffect(() => {
    fetchUserData();
  }, []);

  const fetchUserData = async () => {
    try {
      const response = await fetch("your_mock_api_url");
      const data = await response.json();
      setUserData(data);
    } catch (error) {
      console.error("Error fetching user data:", error);
    }
  };

  return (
    <div>
      <h1>Profile Page</h1>
      {userData && (
        <div>
          <p>Name: {userData.name}</p>
          <p>Country: {userData.country}</p>
          <p>Gender: {userData.gender}</p>
          <p>PAN: {userData.pan}</p>
        </div>
      )}
    </div>
  );
}

export default Profile;
