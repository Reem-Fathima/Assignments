// App.js
import React, { useState } from "react";
import { BrowserRouter as Router, Route } from "react-router-dom";
import Dashboard from "./dashboard/dashboard";
import LoginPage from "./login/login";
import Profile from "./profile/profile";
import UserContext from "./usercontext/UserContext";



function App() {
  const [username, setUsername] = useState(null);

  return (
    <UserContext.Provider value={{ username, setUsername }}>
      <Router>
        <Route path="/" exact component={LoginPage} />
        <Route path="/dashboard" component={Dashboard} />
        <Route path="/profile" component={Profile} />
      </Router>
    </UserContext.Provider>
  );
}

export default App;
